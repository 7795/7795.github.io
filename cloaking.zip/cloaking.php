<?php

$robot_user_agents = array('Googlebot/2.X (+http://www.googlebot.com/bot.html)', 
	'Slurp/2.0', 'MSNBOT/0.1 (http://search.msn.com/msnbot.htm)') #please add more as needed from http://www.user-agents.org/
$robot_ip_addresses = array('209.85.238.11', '141.185.209', '169.207.238' #please add more as needed from http://iplists.com/

$user_agent = $_SERVER['HTTP_USER_AGENT']
$ip_address = $_SERVER['HTTP_REMOTE_ADDR']

if (in_array($user_agent, $robot_user_agents) or in_array($ip_address, $robot_ip_addresses))
{
?>

<H1>Here goes the content intended for the Search Engines</H1>

<?
}else{
?>

<H1>Here goes the content intended for the website visitor</H1>


<?}
?>

